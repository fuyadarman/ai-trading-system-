document.getElementById('trading-form').addEventListener('submit', async function(event) {
    event.preventDefault();
    const marketType = document.getElementById('market-type').value;
    const amount = document.getElementById('amount').value;
    if (amount > 0) {
        try {
            const response = await fetch('http://127.0.0.1:5000/trade', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ market: marketType, amount: parseFloat(amount) })
            });
            const result = await response.json();
            alert(result.message);
        } catch (error) {
            console.error("Error:", error);
            alert("An error occurred while processing your trade.");
        }
    } else {
        alert("Please enter a valid amount.");
    }
});